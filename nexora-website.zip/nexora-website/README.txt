NEXORA WEBSITE — QUICK START

1. Unzip nexora-website.zip.
2. Open index.html to preview the website in a browser.
3. To publish it free: open https://app.netlify.com/drop in your phone browser.
4. Sign in or create a free Netlify account, then upload/drag the folder containing index.html.
5. Netlify will give you a public website URL ending in netlify.app.

EDITING:
- Open index.html in a text/code editor to change text, titles, links and contact email.
- To add a service card, copy one complete <article class="card">...</article> block and edit its heading and paragraph.
- After editing, upload the updated site folder to Netlify again to publish the changes.
- The email button currently uses hello@example.com. Replace it with your own email address before publishing.

This is a starter website. It does not include a private admin login or online content-management panel.
